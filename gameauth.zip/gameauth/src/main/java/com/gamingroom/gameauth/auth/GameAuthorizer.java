package com.gamingroom.gameauth.auth;

import java.security.Principal;

import javax.ws.rs.container.ContainerRequestContext;

import org.checkerframework.checker.nullness.qual.Nullable;

import io.dropwizard.auth.Authorizer;

public class GameAuthorizer implements Authorizer<GameUser> 
{
    /*@Override
    public boolean authorize(GameUser user, String role, @Nullable ContainerRequestContext containerRequestContext) {
    	return user.getRoles() != null && user.getRoles().contains(role);
    }*/ 

	@Override
	public boolean authorize(GameUser principal, String role) {
		return principal.getRoles() != null && principal.getRoles().contains(role);
	}
    
}